import {ReactD3TreeItem} from "react-d3-tree";

export interface ITreeNodeData extends ReactD3TreeItem {
  key: number
  surname?: string
  birthDate?: string
  children?: ITreeNodeData[]
  root?: boolean
}

export type TTree = ITreeNodeData;
