module.exports = function (api) {
  const presets = [];

  api.cache(true);

  if (process.env.NODE_ENV === "test") {
    presets.push("@babel/preset-env");
  }

  return { presets };
}
